![Banner image](https://user-images.githubusercontent.com/10284570/173569848-c624317f-42b1-45a6-ab09-f0ea3c247648.png)

# Siteboon n8n Integration

This n8n integration allows you to interact with the Siteboon API through the Supabase API Gateway.

## Authentication

The integration uses API key authentication via the `x-api-key` header. You'll need to obtain an API key from the Siteboon platform to use this integration.

### API Key Setup

1. Obtain an API key from the Siteboon platform
2. In n8n, create a new credential of type "Siteboon API"
3. Enter your API key in the "API Key" field
4. Save the credential

## Available Resources

### Sites

- **Create Site**: Create a new site
- **Delete Site**: Delete an existing site by ID
- **Get Site**: Retrieve a site by ID
- **Get List of Sites**: Retrieve all sites or a specific site

### Pages

- **Create Page**: Create a new page
- **Delete Page**: Delete an existing page
- **Duplicate Page**: Create a copy of an existing page
- **Get List of Pages**: Retrieve all pages for a site or a specific page
- **Import HTML**: Import HTML content into a page

## API Gateway

This integration uses the Siteboon API Gateway, which:

1. Authenticates requests using API keys
2. Generates JWT tokens for authenticated users
3. Routes requests to the appropriate Supabase Edge Functions
4. Handles error responses

All requests are made to endpoints with the `/api/` prefix, which routes through the API gateway.

## Environment Variables

The API gateway uses the following environment variables:

- `SUPABASE_FUNCTIONS_URL`: Base URL for Supabase functions
- `SUPABASE_URL`: URL of the Supabase project
- `SUPABASE_SERVICE_ROLE_KEY`: Service role key for Supabase
- `SUPABASE_JWT_SECRET`: Secret for JWT token generation

## Troubleshooting

If you encounter authentication issues:

1. Verify that your API key is correct and active
2. Check that the API gateway is properly configured
3. Ensure that the user associated with the API key has the necessary permissions

For other issues, check the Siteboon documentation or contact support.

# n8n-nodes-siteboon

This is an n8n community node. It lets you use Siteboon in your n8n workflows.

Siteboon is a website builder and content management system that provides API endpoints for managing sites and pages.

[n8n](https://n8n.io/) is a [fair-code licensed](https://docs.n8n.io/reference/license/) workflow automation platform.

[Installation](#installation)  
[Operations](#operations)  
[Credentials](#credentials)  
[Compatibility](#compatibility)  
[Resources](#resources)  

## Installation

Follow the [installation guide](https://docs.n8n.io/integrations/community-nodes/installation/) in the n8n community nodes documentation.

## Operations

### Site
- **Create**: Create a new site
- **Delete**: Delete a site
- **Get**: Get a site by ID
- **Get List**: Get list of sites

### Page
- **Create**: Create a new page
- **Delete**: Delete a page
- **Duplicate**: Duplicate a page
- **Get List**: Get list of pages
- **Import HTML**: Import HTML content to a page

## Credentials

You need an API key to authenticate with Siteboon API.

1. Contact Siteboon administrator to obtain your API key
2. Use this key in the Siteboon API credentials in n8n

## Compatibility

This node has been tested with n8n version 1.0.0 and above.

## Resources

* [n8n community nodes documentation](https://docs.n8n.io/integrations/community-nodes/)
* [Siteboon Documentation](https://siteboon.com/docs) <!-- Replace with actual documentation URL -->

## License

[MIT](https://github.com/n8n-io/n8n-nodes-starter/blob/master/LICENSE.md)
